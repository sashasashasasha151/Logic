#include <vector>
#include <string>
#include <unordered_map>
using namespace std;

unordered_map<string,int> mp;
