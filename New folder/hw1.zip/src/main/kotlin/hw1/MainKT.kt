package main.kotlin.hw1

object MainKT {
    @JvmStatic
    fun main(args: Array<String>) {
        var r = 1
        while (true) {
            r++
            r--
        }
    }
}