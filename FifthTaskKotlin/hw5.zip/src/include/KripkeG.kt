package include

class KripkeV {
    var parent: Int? = null
    var forced: HashSet<String> = hashSetOf()
    var space: Int? = null
}